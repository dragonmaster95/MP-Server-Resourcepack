package a;

import java.io.FileWriter; // Import the FileWriter class
import java.io.IOException;  // Import the IOException class to handle errors

/**
 * Hello world!
 *
 */
public class App 
{
  public static void main(final String[] args) {
    final int iterations = 80;

    for (int i = 0; i<iterations; i++) {
      createModel(i, 0, iterations);
      if (i > 64) {
        for (int j = 1; j<5; j++) {
          createModel(i, j, iterations);
        }
      }
    }
    //createFunction(iterations);

  }

  public static void createModel(int i, int j, int max) {
      String text = "{\n";
      try {
        FileWriter myWriter;
        if (j==0) {
          System.out.println("\t{ \"predicate\": {\"custom_model_data\": "+(i*5+10+j)+"}, \"model\": \"minigame/bb/balloon/balloon_"+i+"\"},");
          myWriter = new FileWriter(
            "C:\\Users\\user\\AppData\\Roaming\\.minecraft\\resourcepacks\\Mario-Party-Resourcepack\\assets\\minecraft\\models\\minigame\\bb\\balloon\\balloon_"
                + i + ".json");   
        } else {
          System.out.println("\t{ \"predicate\": {\"custom_model_data\": "+(i*5+10+j)+"}, \"model\": \"minigame/bb/balloon/balloon_"+i+"_"+j+"\"},");
          myWriter = new FileWriter(
            "C:\\Users\\user\\AppData\\Roaming\\.minecraft\\resourcepacks\\Mario-Party-Resourcepack\\assets\\minecraft\\models\\minigame\\bb\\balloon\\balloon_"
                + i + "_" + j + ".json");   
        }
        
        text += "\t\"parent\": \"minigame/bb/balloon/bowser_balloon_template\",\n";
        int offset = i-2;
        if (offset>56 && offset%8 != 0) text += " \t\"textures\": {\n"+
                "\t\t\"face\": \"minigames/bb/bowser_balloon_"+j+"\"\n"+
            "\t},\n";

        float size = 2.0f+2.0f*i/max;
        float volume = 0.1f+3.9f*i/max;
        text += "\t\"display\": {\n"+
            "\t\t\"head\": {\n"+
                "\t\t\t\"scale\": ["+size+", "+size+", "+volume+"]\n"+
            "\t\t}\n"+
            "\t}\n";

        text +="}";
        myWriter.write(text);
        myWriter.close();
      } catch (final IOException e) {
        System.out.println("An error occurred.");
        e.printStackTrace();
      }
  }

  public static void moreVersions(int i, int j) {

  }

  public static void createFunction(int iterations) {
    String text = "";
    try {
      FileWriter myWriter = new FileWriter( "C:\\Users\\user\\AppData\\Roaming\\.minecraft\\resourcepacks\\Mario-Party-Resourcepack\\assets\\minecraft\\models\\minigame\\bb\\balloon\\setballoon.mcfunction");   
          
      text+="data merge entity @s ";

      for (int i=0; i<iterations; i++) {
        text+="execute if score @s matches "+i+" run data merge entity @s";
      }
          
      myWriter.write(text);
      myWriter.close();
      System.out.println("Successfully wrote to the file.");
    } catch (final IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
  }
}
